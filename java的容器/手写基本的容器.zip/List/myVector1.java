package test9;

import java.util.List;
import java.util.Vector;

public class myVector1 {
	public static void main(String[] args) {
		List<String> a = new Vector<>();
		a.add("sss");
		System.out.println(a);
	}
}
